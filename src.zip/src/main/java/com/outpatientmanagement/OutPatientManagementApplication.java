package com.outpatientmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutPatientManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutPatientManagementApplication.class, args);
	}

}
