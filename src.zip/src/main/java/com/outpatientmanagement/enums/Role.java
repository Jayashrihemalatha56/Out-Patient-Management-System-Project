package com.outpatientmanagement.enums;

public enum Role {

	PATIENT,
	DOCTOR,
	ADMIN
}
